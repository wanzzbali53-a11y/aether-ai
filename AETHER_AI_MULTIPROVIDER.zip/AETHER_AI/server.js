// AETHER AI multi-provider backend — Node.js 20+
import http from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const PROVIDERS = {
  gemini: {
    key: process.env.GEMINI_API_KEY,
    url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    model: process.env.GEMINI_MODEL || "gemini-2.5-flash",
    label: "Gemini"
  },
  groq: {
    key: process.env.GROQ_API_KEY,
    url: "https://api.groq.com/openai/v1/chat/completions",
    model: process.env.GROQ_MODEL || "openai/gpt-oss-20b",
    label: "Groq"
  },
  openrouter: {
    key: process.env.OPENROUTER_API_KEY,
    url: "https://openrouter.ai/api/v1/chat/completions",
    model: process.env.OPENROUTER_MODEL || "openrouter/free",
    label: "OpenRouter"
  }
};
const MAX_BODY = 100_000;
const rate = new Map();

function send(res, status, data, type="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type":type, "X-Content-Type-Options":"nosniff", "Cache-Control":"no-store"});
  res.end(type.startsWith("application/json") ? JSON.stringify(data) : data);
}
async function readBody(req) {
  let raw = "";
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > MAX_BODY) throw new Error("Pesan terlalu besar.");
  }
  return JSON.parse(raw || "{}");
}
function providerOrder(preference) {
  const all = ["gemini", "groq", "openrouter"];
  if (preference === "auto" || !preference) return all;
  return [preference, ...all.filter(p => p !== preference)];
}
async function askProvider(name, messages, requestedModel) {
  const p = PROVIDERS[name];
  if (!p.key) throw new Error(`${p.label}: API key belum dipasang di server.`);
  const model = requestedModel && requestedModel !== "auto" ? requestedModel : p.model;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45_000);
  try {
    const headers = {
      "Authorization": `Bearer ${p.key}`,
      "Content-Type": "application/json"
    };
    if (name === "openrouter") {
      headers["HTTP-Referer"] = process.env.APP_URL || "https://aether-ai.app";
      headers["X-Title"] = "AETHER AI";
    }
    const upstream = await fetch(p.url, {
      method: "POST",
      headers,
      signal: controller.signal,
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.7,
        max_tokens: 4096,
        stream: false
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const message = data?.error?.message || data?.message || `HTTP ${upstream.status}`;
      throw new Error(`${p.label}: ${message}`);
    }
    const reply = data?.choices?.[0]?.message?.content;
    const text = typeof reply === "string" ? reply :
      Array.isArray(reply) ? reply.map(part => part.text || "").join("") : "";
    if (!text.trim()) throw new Error(`${p.label}: model tidak mengirim teks jawaban.`);
    return { reply: text, provider: name, providerLabel: p.label, model: data.model || model };
  } finally {
    clearTimeout(timeout);
  }
}
const server = http.createServer(async (req, res) => {
  const ip = req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.socket.remoteAddress || "unknown";
  if (req.method === "GET" && req.url === "/api/health") {
    const configured = Object.entries(PROVIDERS).filter(([,p]) => Boolean(p.key)).map(([name]) => name);
    return send(res, 200, { ok: true, ready: configured.length > 0, providers: configured });
  }
  if (req.method === "POST" && req.url === "/api/chat") {
    const now = Date.now(), entry = rate.get(ip) || { start: now, count: 0 };
    if (now - entry.start > 60_000) { entry.start = now; entry.count = 0; }
    entry.count++; rate.set(ip, entry);
    if (entry.count > 20) return send(res, 429, { error: "Terlalu banyak pesan. Coba lagi sebentar." });
    try {
      const input = await readBody(req);
      if (!Array.isArray(input.messages) || input.messages.length === 0) return send(res, 400, { error: "Pesan chat kosong." });
      const messages = input.messages.slice(-24).map(m => ({
        role: ["system", "user", "assistant"].includes(m.role) ? m.role : "user",
        content: String(m.content || "").slice(0, 20000)
      }));
      const preference = ["auto", "gemini", "groq", "openrouter"].includes(input.provider) ? input.provider : "auto";
      const requestedModel = typeof input.model === "string" ? input.model : "auto";
      const failures = [];
      for (const name of providerOrder(preference)) {
        if (!PROVIDERS[name].key) { failures.push(`${PROVIDERS[name].label}: key belum tersedia`); continue; }
        try {
          const result = await askProvider(name, messages, requestedModel === "auto" ? null : requestedModel);
          return send(res, 200, result);
        } catch (err) {
          failures.push(err.message || `${PROVIDERS[name].label}: gagal`);
        }
      }
      return send(res, 502, {
        error: "Semua provider AI gagal atau belum dikonfigurasi.",
        details: failures
      });
    } catch (err) {
      return send(res, 400, { error: err.message || "Permintaan tidak valid." });
    }
  }
  if (req.method === "GET" && (req.url === "/" || req.url === "/index.html")) {
    try {
      const html = await readFile(path.join(here, "public", "index.html"));
      return send(res, 200, html, "text/html; charset=utf-8");
    } catch { return send(res, 500, { error: "File aplikasi tidak ditemukan." }); }
  }
  return send(res, 404, { error: "Tidak ditemukan." });
});
server.listen(PORT, () => console.log(`AETHER AI berjalan di port ${PORT}`));
