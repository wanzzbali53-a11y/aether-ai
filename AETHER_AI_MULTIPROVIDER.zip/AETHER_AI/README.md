# AETHER AI — Multi-provider

Aplikasi chat AETHER AI dengan backend multi-provider Gemini, Groq, dan OpenRouter.

## Cara kerja
- Mode `Auto` mencoba Gemini → Groq → OpenRouter.
- Jika satu provider tidak memiliki key, provider tersebut dilewati.
- Jika provider gagal (misalnya kuota/rate limit/model tidak tersedia), backend mencoba provider berikutnya.
- Pengguna aplikasi tidak pernah diminta memasukkan API key.
- API key hanya disimpan sebagai environment variables di server hosting.

## Persiapan
Diperlukan Node.js 20+.

1. Salin `.env.example` menjadi `.env` untuk pengujian lokal.
2. Isi satu atau lebih API key:
   - `GEMINI_API_KEY` dari https://aistudio.google.com/app/apikey
   - `GROQ_API_KEY` dari https://console.groq.com/keys
   - `OPENROUTER_API_KEY` dari https://openrouter.ai/keys
3. Jalankan:
   ```bash
   npm start
   ```
4. Buka `http://localhost:3000`.

Untuk hosting, masukkan key pada bagian Environment Variables/Secrets di dashboard hosting. Jangan unggah `.env` atau menaruh key di folder `public`.

## Model default
- Gemini: `gemini-2.5-flash`
- Groq: `openai/gpt-oss-20b`
- OpenRouter: `openrouter/free`

Model bisa berubah ketersediaan atau ketentuan. Ubah environment variable `GEMINI_MODEL`, `GROQ_MODEL`, atau `OPENROUTER_MODEL` bila diperlukan. Untuk fallback otomatis paling aman, biarkan model `auto` dipilih di antarmuka; tiap provider memakai model default masing-masing.

## Endpoint API
- `GET /api/health` — status server dan daftar provider yang memiliki key.
- `POST /api/chat` — menerima `{ "provider":"auto", "model":"auto", "messages":[...] }`.

## Penting tentang biaya dan kuota
Aplikasi tidak menjamin gratis atau tanpa batas. Setiap penyedia memiliki rate limit, kuota, dan model berbayar yang dapat berubah. OpenRouter `openrouter/free` mengarahkan ke model gratis yang tersedia, tetapi tetap memiliki batas penggunaan. Pantau dashboard tiap penyedia.

## Batasan versi
- Chat teks berjalan melalui provider yang telah dikonfigurasi.
- Pemilihan file di UI lama belum mengunggah atau membaca isi file.
- Tidak ada generator gambar AI.
- Riwayat chat disimpan lokal pada browser.
- Musik MP3 dan latar foto/video bersumber dari file perangkat pengguna dan hanya berlaku di browser tersebut.
- Untuk aplikasi publik, tambahkan monitoring, proteksi abuse, dan batas biaya pada akun provider.
